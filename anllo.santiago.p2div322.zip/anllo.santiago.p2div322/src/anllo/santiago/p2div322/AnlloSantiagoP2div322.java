package anllo.santiago.p2div322;

import java.io.IOException;
import model.Receta;
import model.TipoReceta;
import repository.LibroDeRecetas;

public class AnlloSantiagoP2div322 {


    public static void main(String[] args) {
        
        try {
       
            // Crear un libro de recetas
            LibroDeRecetas<Receta> libro = new LibroDeRecetas<>();
            libro.agregar(new Receta(1, "Tarta de Verdura", "Abuela Rosa", TipoReceta.VEGETARIANA)); 
            libro.agregar(new Receta(2, "Pollo al horno", "Juan Pérez", TipoReceta.PLATO_PRINCIPAL)); 
            libro.agregar(new Receta(3, "Ensalada César", "Laura Ruiz", TipoReceta.ENTRADA)); 
            libro.agregar(new Receta(4, "Brownie", "Chef Martín", TipoReceta.POSTRE)); 
            libro.agregar(new Receta(5, "Pan sin gluten", "Lucía Gómez", TipoReceta.SIN_TACC));
            
            System.out.println("Libro de recetas:");
            libro.paraCadaElemento(System.out::println);
            
            
            System.out.println("\nRecetas VEGETARIANAS:");
            libro.filtrar(r -> r.getTipo() == TipoReceta.VEGETARIANA)
                 .forEach(r -> System.out.println(r));
            
            System.out.println("\nRecetas que contiene 'tarta' :");
            libro.filtrar((r) -> r.getNombre().toLowerCase().contains("tarta")).forEach(r-> System.out.println(r));
            
            System.out.println("\nRecetas ordenadas por ID:");
            libro.ordenar();
            libro.paraCadaElemento(r -> System.out.println(r));
            
            System.out.println("\nRecetas ordenadas por nombre:");
            libro.ordenar((r1, r2) -> r1.getNombre().compareToIgnoreCase(r2.getNombre()));
            libro.paraCadaElemento(r -> System.out.println(r));
            
            libro.guardarEnArchivos("src/data/recetas.dat");
            
            LibroDeRecetas<Receta> libroCargado = new LibroDeRecetas<>(); 
            libroCargado.cargarDesdeArchivo("src/data/recetas.dat"); 
            System.out.println("\nRecetas cargadas desde archivo binario:");
            libroCargado.paraCadaElemento(r -> System.out.println(r));
            
            libro.guardarEnCSV("src/data/recetas.csv");
            
            // Cargar el libro desde archivo CSV 
            libroCargado.cargarDesdeCSV("src/data/recetas.csv"); 
            System.out.println("\nRecetas cargadas desde archivo CSV:");
            libroCargado.paraCadaElemento(System.out::println);
            
            
            }catch(IOException e) { 
                System.err.println("Error: " + e.getMessage());
            }
    }
}
        
        

