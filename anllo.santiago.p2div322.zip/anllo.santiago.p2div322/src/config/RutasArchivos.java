package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface RutasArchivos {
    
    static final String BASE = "src/data";
    static final String CSV = "recetas.csv";
    static final String BIN = "recetas.dat";

    static Path getRutaCSV(){
        return Paths.get(BASE,CSV);
    }
    
    static Path getRutaBin(){
        return Paths.get(BASE,BIN);
    }
    
    static String getRutaCSVString(){
        return Paths.get(BASE,CSV).toString();
    }
    
    static String getRutaBinString(){
        return Paths.get(BASE,BIN).toString();
    }
    
}
