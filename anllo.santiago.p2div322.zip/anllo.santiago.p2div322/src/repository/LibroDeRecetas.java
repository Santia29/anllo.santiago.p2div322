
package repository;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import model.CSVSerializable;
import model.Receta;

public class LibroDeRecetas<T extends CSVSerializable & Comparable<T>> implements Serializable  {
    
    private final List<T> items;

    public LibroDeRecetas() {
        items = new ArrayList<>();
    }
            
    public void agregar(T item) {
        checkItem(item);
        items.add(item);
    }
    
    private void checkItem(T item){
        if(item == null){
            throw new NullPointerException("elemento nulo");
        }
        if(contiene(item)){
            throw new IllegalArgumentException("item repetido");
        }
    }
    
    public void eliminarPorIndice(int indice) {
        checkIndice(indice);
        items.remove(indice);
    }
    
    
    public T obtener(int indice) {
        checkIndice(indice);
        return items.get(indice);
    }
    
    private void checkIndice(int indice){
        if(indice < 0 || indice >= items.size()){
            throw new IndexOutOfBoundsException("indice invalido");
        }
    }
       
    public boolean contiene(T item) {
        return items.contains(item);
    }
    
    public List<T> filtrar(Predicate<? super T> criterio){
        List<T> copia = new ArrayList<>();
        for(T item : items){
            if(criterio.test(item)){ 
                copia.add(item);
            }
        }
        return copia;
    }
    public void paraCadaElemento(Consumer<? super T> accion) {
        for(T item : items){
            accion.accept(item);
        }
    }
    
    public Iterator<T> iterator() {
        if(!items.isEmpty() && obtener(0) instanceof Comparable){
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return items.iterator();

    }
    
    public Iterator<T> iterator(Comparator<? super T> comparador) {
        List<T> copia = new ArrayList<>(items);
            Collections.sort(copia, comparador);
            return copia.iterator();
    }

    public void guardarEnCSV(String path){
        try(BufferedWriter bf = new BufferedWriter(new FileWriter(path))) {
            bf.write(Receta.toCSVHeader());
            for(Receta e : items){
                bf.write(e.toCSV() + "\n");
            }
            
            } catch (IOException ex) {
            System.out.println(ex.getMessage());
            }
    }
    //lectura de CSV
    public List<Receta> cargarDesdeCSV(String path){
        List<Receta> empleados = null;
        try(BufferedReader bf = new BufferedReader(new FileReader(path))) {
            empleados = new ArrayList<>();
            String linea;
            bf.readLine(); //lectura fantasma;
            while((linea = bf.readLine()) != null){
                empleados.add(Receta.fromCSV(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return empleados;
}   
    
    //guarda en binario
    public void guardarEnArchivos(String path) throws IOException{
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            
            salida.writeObject(items);
                                                 
        }
    }

    public List<Receta> cargarDesdeArchivo(String path){
        List<Receta> empleados = null; 
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            empleados = (List<Receta>)entrada.readObject();
            System.out.println(empleados);
        }catch(IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
        return empleados;
    }
       
    public void ordenar() {
        Collections.sort(items);
    }
    
    public void ordenar(Comparator<T> comparator) {
        items.sort(comparator);
    }

    
    
}
