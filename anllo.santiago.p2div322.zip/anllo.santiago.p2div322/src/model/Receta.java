package model;

public class Receta implements CSVSerializable, Comparable<Receta>{
    
    private int id;
    private String nombre;
    private String autor;
    private TipoReceta tipo;

    public Receta(int id, String nombre, String autor, TipoReceta tipo) {
        this.id = id;
        this.nombre = nombre;
        this.autor = autor;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Receta{" + "id=" + id + ", nombre=" + nombre + ", autor=" + autor + ", tipo=" + tipo + '}';
    }
    
    
    
    public static String toCSVHeader(){
        
        return "id, nombre, auto, tipo\n";
        
    }
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAutor() {
        return autor;
    }

    public TipoReceta getTipo() {
        return tipo;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + autor + "," + tipo;
    }

    @Override
    public int compareTo(Receta r) {
        return Integer.compare(this.id, r.id);
    }
    
    public static Receta fromCSV(String recetasCSV){
        Receta r = null;
        if(recetasCSV.endsWith("\n")){
            recetasCSV = recetasCSV.substring(0, recetasCSV.length() -1 );
        }
        String [] values = recetasCSV.split(",");
        if(values.length == 4){
            int dni = Integer.parseInt(values[0]);
            String nombre = values[1];
            String autor = values[2];
            TipoReceta tipo = TipoReceta.valueOf(values[3]);;
                
            r = new Receta(dni,nombre,autor,tipo);
        }
                
        return r;
    }
}
    
    
    
    

